var express = require('express');
var router = express.Router();
const passport=require("passport")
var mongoose = require('mongoose');

const users_data=require("../model.db/human")
const patient_data=users_data.patient_data
const doctor_data=users_data.doctor_data
const admin_data=users_data.admin_data
const other_data=require("../model.db/APPointmentsandprescriptions")
const prescription_data=other_data.prescription_data
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('home', { title: 'Express' });
});

router.get("/homeaftersignin",(req,res,err)=>{
  res.render("homeaftersignin")
})
router.get("/prescription",(req,res,next)=>{
  var id = mongoose.Types.ObjectId(req.session.passport.user[0]._id)
  
 patient_data.aggregate([{

  
  
    $lookup:{
      from:"prescriptions",
      localField:"_id",
      foreignField:"pat_id",
      as :"patient_prec"

    },
   
  },
  {
    $match:
    {"_id":id}
  }
],
  (err,docs)=>{
    if(err){
      console.log(err)
    }
    else{
    // var x=docs[0].patient_prec
    // console.log(docs)
    // console.log(typeof(id))
     if(Object.keys(docs).length===0)
     {
      res.render("patientprescription",{message:"NO Prescription have been prescribed"})
     }
     else{
      var x=docs[0].patient_prec
      res.render("patientprescription",{data:x})

     }
     
   
  }
}
  )
})

router.get("/addpre",(req,res,next)=>{
  res.render("addprescription",{msg:"This ID is not found"})
})

router.post("/addpres",(req,res,next)=>{
  var pat_id=mongoose.Types.ObjectId(req.body.pat_id)
  var doc_id=mongoose.Types.ObjectId(req.session.passport.user[0]._id)
  console.log("vvvvvvvvvvvvvv")
  console.log(typeof(pat_id))
  console.log(req.session.passport.user[0]._id)
  patient_data.find({_id:pat_id},(err,result)=>{
    if(err)
    {
      console.log(err)
    }
    else{
      if(Object.keys(result).length===0)
      {
        console.log("aaaaaaaa")
        res.redirect('addpre')
      }
      else{
        
  prescription_data.collection.insertOne({
    pat_id:pat_id,
    Dosage:req.body.dosage,
    Nameofmedicine:req.body.name,
    doc_id:doc_id, 
    contraindications:req.body.cont
  
  
  },(err,docs)=>{
    if(err)
    {
      console.log(err)

    }
    else{
      console.log("bbbbbbbbbb")
      console.log(docs)
      res.redirect("users/profile")
    }
  })
       
      }
    }
  }
  
  )

})
router.get("/addp",(req,res,next)=>{
  res.render("addprescription")
})


module.exports = router;
